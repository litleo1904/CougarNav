import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.web.WebView;
import javafx.geometry.Insets;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONObject;
import org.json.JSONArray;

public class CougarNavApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("CSUSM Campus Map");

        // Sidebar with Navigation Menu
        Accordion sidebar = new Accordion();
        sidebar.setStyle("-fx-background-color: #212529; -fx-text-fill: white;");

        // Search Bar
        TextField searchField = new TextField();
        searchField.setPromptText("Search resources...");
        searchField.setStyle("-fx-background-color: #495057; -fx-text-fill: white; -fx-prompt-text-fill: gray; -fx-border-color: #6c757d;");
        searchField.setFont(Font.font("Arial", 14));

        // Student Resources Section
        VBox studentResourcesBox = new VBox(10);
        studentResourcesBox.setPadding(new Insets(10));
        studentResourcesBox.setStyle("-fx-background-color: #495057;");
        studentResourcesBox.getChildren().addAll(
            createResourceLinkWithContact(
                "Academic Support",
                "https://www.csusm.edu/students/needs/academic-support/index.html",
                "(760) 750-4101",
                "academicsupport@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Library Resources",
                "https://biblio.csusm.edu",
                "(760) 750-4348",
                "library@csusm.edu"
            )
            ,
            createResourceLinkWithContact(
                "Career Services",
                "https://www.csusm.edu/careers/index.html",
                "(760) 750-4900",
                "careerservices@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Financial Aid",
                "https://www.csusm.edu/finaid/index.html",
                "(760) 750-4850",
                "finaid@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Mental Health Services",
                "https://www.csusm.edu/shcs/index.html",
                "(760) 750-4915",
                "counseling@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Disability Support Services",
                "https://www.csusm.edu/dss/",
                "(760) 750-4905",
                "dss@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Student Organizations",
                "https://www.csusm.edu/orgs/index.html",
                "(760) 750-4970",
                "studentorgs@csusm.edu"
            )
        );
        TitledPane studentResourcesPane = new TitledPane("Student Resources", studentResourcesBox);
        studentResourcesPane.setStyle("-fx-background-color: #212529; -fx-text-fill: white;");



        // Campus Resources Section
        VBox campusResourcesBox = new VBox(10);
        campusResourcesBox.setPadding(new Insets(10));
        campusResourcesBox.setStyle("-fx-background-color: #495057;");
        campusResourcesBox.getChildren().addAll(
            createResourceLinkWithContact(
                "Campus Map",
                "https://www.csusm.edu/about/maps/index.html",
                "(760) 750-4500",
                "campusmap@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Dining Services",
                "https://www.csusm.edu/dining/index.html",
                "(760) 750-4785",
                "dining@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Parking & Transportation",
                "https://www.csusm.edu/parking/index.html",
                "(760) 750-7500",
                "parking@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Bookstore",
                "https://www.bkstr.com/csusmstore/home",
                "(760) 750-4730",
                "bookstore@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Athletic Facilities",
                "https://www.csusm.edu/rec/index.html",
                "(760) 750-6000",
                "athletics@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Study Spaces",
                "https://www.csusm.edu/students/needs/study-spaces/index.html",
                "(760) 750-4750",
                "studyspaces@csusm.edu"
            ),
            createResourceLinkWithContact(
                "Emergency Services",
                "https://www.csusm.edu/police/index.html",
                "(760) 750-4567",
                "emergency@csusm.edu"
            )
        );
        TitledPane campusResourcesPane = new TitledPane("Campus Resources", campusResourcesBox);
        campusResourcesPane.setStyle("-fx-background-color: #212529; -fx-text-fill: white;");

        // Adding panes to Sidebar
        sidebar.getPanes().addAll(studentResourcesPane, campusResourcesPane);

        VBox sidebarBox = new VBox(10, searchField, sidebar);
        sidebarBox.setStyle("-fx-background-color: #212529; -fx-padding: 10;");
        sidebarBox.setPrefWidth(300);

        // Main Map View
        WebView mapView = new WebView();
        mapView.getEngine().load("https://www.google.com/maps/d/embed?mid=1O7Hn5RetxsbdRTnv9vB8MlwW9bHbOSI&usp=sharing");
        mapView.setStyle("-fx-background-color: #f8f9fa;");
        mapView.setPrefSize(800, 600);

        // Chat Interface
        ScrollPane chatScrollPane = new ScrollPane();
        VBox chatArea = new VBox(10);
        chatArea.setPadding(new Insets(10));
        chatArea.setStyle("-fx-background-color: #1e3a5f;");

        chatScrollPane.setContent(chatArea);
        chatScrollPane.setFitToWidth(true);
        chatScrollPane.setStyle("-fx-background: #1e3a5f;");


        TextField userQuery = new TextField();
        userQuery.setPromptText("Ask CougarNav AI...");
        userQuery.setStyle("-fx-background-color: #495057; -fx-text-fill: white; -fx-prompt-text-fill: gray;");

        Button sendButton = new Button("Send");
        sendButton.setStyle("-fx-background-color: #007bff; -fx-text-fill: white;");

        sendButton.setOnAction(e -> {
            String query = userQuery.getText();
            if (!query.isEmpty()) {
                // User message
                Label userMessage = new Label("You: " + query);
                userMessage.setFont(Font.font("Arial", FontWeight.BOLD, 14));
                userMessage.setTextFill(Color.LIGHTBLUE);
                userMessage.setWrapText(true);
                chatArea.getChildren().add(userMessage);

                // AI response
                String aiResponse = askChatAI(query);
                Label aiMessage = new Label("AI: " + aiResponse);
                aiMessage.setFont(Font.font("Arial", FontPosture.ITALIC, 14));
                aiMessage.setTextFill(Color.WHITE);
                aiMessage.setWrapText(true);
                chatArea.getChildren().add(aiMessage);

                userQuery.clear();
            }
        });
        

        VBox chatBox = new VBox(10, chatArea, userQuery, sendButton);
        chatBox.setPadding(new Insets(10));
        chatBox.setStyle("-fx-background-color: #212529;");
        chatBox.setPrefWidth(300);

        // Layout
        HBox contentBox = new HBox(10, sidebarBox, mapView, chatBox);
        contentBox.setPadding(new Insets(20));
        contentBox.setStyle("-fx-background-color: #f8f9fa;");

        BorderPane layout = new BorderPane();
        layout.setCenter(contentBox);

        // Footer
        Label footer = new Label("© 2024 CSUSM Navigation | Designed by CougarNav Team");
        footer.setStyle("-fx-background-color: #212529; -fx-text-fill: white; -fx-padding: 10; -fx-font-size: 12;");
        footer.setMaxWidth(Double.MAX_VALUE);
        footer.setAlignment(javafx.geometry.Pos.CENTER);

        VBox root = new VBox();
        root.getChildren().addAll(layout, footer);

        // Scene Setup
        Scene scene = new Scene(root, 1100, 700);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Helper Method to Create Links with Contact Info
    private VBox createResourceLinkWithContact(String name, String url, String phone, String email) {
        Hyperlink link = new Hyperlink(name);
        link.setStyle("-fx-text-fill: white;");
        link.setOnAction(e -> getHostServices().showDocument(url));

        Label contactInfo = new Label("Phone: " + phone + " | Email: " + email);
        contactInfo.setStyle("-fx-text-fill: white; -fx-font-size: 12;");

        VBox resourceBox = new VBox(5, link, contactInfo);
        resourceBox.setPadding(new Insets(5));
        return resourceBox;
    }

    // AI Chat Method
    private String askChatAI(String query) {
        try {
            String apiUrl = "https://api.openai.com/v1/chat/completions";
            String apiKey = "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"; // Replace with your actual OpenAI API key
    
            String jsonInput = String.format(
                "{\"model\": \"gpt-3.5-turbo\", \"messages\": [{\"role\": \"system\", \"content\": \"You are a helpful assistant for CSUSM students.\"}, {\"role\": \"user\", \"content\": \"%s\"}], \"temperature\": 0.7}",
                query
            );
    
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(jsonInput))
                .build();
    
            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            //testing below
            System.out.println("Raw Response: " + response.body());
            //testing above

            // Parse the JSON response using JSONObject
            JSONObject jsonResponse = new JSONObject(response.body());
            JSONArray choices = jsonResponse.getJSONArray("choices");
            JSONObject firstChoice = choices.getJSONObject(0);
            JSONObject message = firstChoice.getJSONObject("message");
            return message.getString("content").trim();
        } catch (Exception e) 
        {
            e.printStackTrace();
            System.err.println("Error details: " + e.getMessage());
            return "Error communicating with AI";
        }
    }
    

    public static void main(String[] args) {
        launch(args);
    }
}
/*
api key 

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


*/